import shutil

#we can copy file o extract file from anywhere that we want to do
shutil.make_archive('output','zip')